package moh.real_estate_management.types;

public enum ListingType {
    FOR_SALE,
    FOR_RENT
}
