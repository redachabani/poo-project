package moh.real_estate_management.types;

public enum TransactionType {
    BUY,
    SELL,
    RENT ,
}
