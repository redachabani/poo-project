package moh.real_estate_management.types;

public enum PropertyAvailability {
    AVAILABLE,
    NOT_AVAILABLE
}
